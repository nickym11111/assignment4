import model.IPortfolio;

import model.StockMarket;

import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.util.HashMap;

import model.IStock;
import model.Stock;


import static org.junit.Assert.*;

/**
 * A test class that make sures that the portfolios and stocks
 * are properly being stored.
 */
public class StockMarketTest {

  private StockMarket stockMarket;
  private IStock stock;
  IStock copyOfGoogle = new Stock("GOOG");

  @Before
  public void setUp() throws FileNotFoundException {
    stockMarket = new StockMarket();
    stock = new Stock("GOOG");

  }

  @Test
  public void testAddStock() {
    stockMarket.addStock("GOOG", stock);
    assertTrue(stockMarket.checkStock("GOOG"));
  }


  @Test
  public void testAddPortfolio() {
    stockMarket.addPortfolio("Tech");
    assertTrue(stockMarket.checkPortfolio("Tech"));
  }

  @Test
  public void testCheckPortfolioNotPresent() {
    assertFalse(stockMarket.checkPortfolio("Health"));
  }

  @Test
  public void testGetPortfolio() {
    stockMarket.addPortfolio("Finance");
    IPortfolio portfolio = stockMarket.getPortfolio("Finance");
    assertNotNull(portfolio);
    assertEquals("Finance", portfolio.getName());
  }

  @Test
  public void testGetPortfolioNotPresent() {
    assertNull(stockMarket.getPortfolio("Unknown"));
  }

  @Test
  public void testGetPortfolios() {
    stockMarket.addPortfolio("Tech");
    stockMarket.addPortfolio("Health");
    HashMap<String, IPortfolio> portfolios = stockMarket.getPortfolios();

    assertTrue(portfolios.containsKey("Tech"));
    assertTrue(portfolios.containsKey("Health"));
  }

  @Test
  public void testGetStocks() {
    stockMarket.addStock("GOOG", stock);
    HashMap<String, IStock> stocks = stockMarket.getStocks();

    assertTrue(stocks.containsKey("GOOG"));
  }

  @Test
  public void testAddDuplicateStock() {
    stockMarket.addStock("GOOG", stock);
    stockMarket.addStock("GOOG", copyOfGoogle);
    HashMap<String, IStock> stocks = stockMarket.getStocks();
    assertEquals(7, stocks.size());
    assertEquals(copyOfGoogle, stocks.get("GOOG"));
  }

  @Test
  public void testAddStockWithEmptyTickerSymbol() {
    stockMarket.addStock("", stock);
  }


}