package view;

import java.util.ArrayList;
import java.util.Map;

import model.ISmartPortfolio;

public interface IViewGUI extends IView{
  void addViewListener(IViewListener viewListener);
  void requestFocus();
  void setVisible(boolean value);
  void displayPortfolios(String portfolios);
  public void setPortfolioButtons(ArrayList<String> portfolios);

  void displayHeader();
  void displayButtonOptions();
  void displayPort();
}
