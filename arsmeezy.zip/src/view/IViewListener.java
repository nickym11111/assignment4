package view;

/**
 * Created by vidojemihajlovikj on 6/11/24.
 */
public interface IViewListener {
  // all controller commands
  void handleDisplayPortfolios();

  void getPortfolioButtons();
}
