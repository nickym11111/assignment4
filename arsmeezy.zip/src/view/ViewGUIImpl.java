package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.swing.*;

import model.ISmartPortfolio;

public class ViewGUIImpl extends JFrame implements IViewGUI, ActionListener {

  private final JButton createPortfolio = new JButton("Create Portfolio");
  private final JButton  buyStock = new JButton("Buy Stock");
  private final JButton  sellStock = new JButton("Sell Stock");
  private final JButton valueOfPortfolio = new JButton("Value of Portfolio");
  private final JButton composition = new JButton("Composition of Portfolio");
  private final JPanel mainPanel = new JPanel();
  private ArrayList<JButton> portfolioButtons;


  //  private final JLabel  enterTextLabel;
//  private final JTextArea enterTextArea;
  private final List<IViewListener> myListeners;

  public ViewGUIImpl(){
    super("Stock Portfolio Manager");
    setSize(new Dimension(800, 400));
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    this.myListeners = new ArrayList<>();
    setLayout(new BorderLayout());

    portfolioButtons = new ArrayList<>();

//    setFocusable(true);
//    requestFocus();

    // pack();
    setVisible(true);

  }


  @Override
  public void writeMessage(String message) {

  }

  @Override
  public void actionPerformed(ActionEvent e) {
    switch ( e.getActionCommand() ){
      case "getData":
        // fireGetDataEvent();
        break;
      case "sendData":
        // fireSetDataEvent();
        break;
      default:
        throw new IllegalStateException("Unknown action command");
    }
    //Which button got cliked!
  }

  private void getPortfolioButtions() {
    for ( IViewListener myListener : myListeners ){
      myListener.getPortfolioButtons();
    }
  }


  public void setPortfolioButtons(ArrayList<String> names) {
    for (int i = 0; i < names.size(); i++){
      JButton button = new JButton(names.get(i));
      portfolioButtons.add(button);
      portfolioButtons.get(i).addActionListener(this);
    }
  }


  @Override
  public void displayPortfolios(String portfolioName) {
    for( IViewListener myListener : myListeners ){
      myListener.handleDisplayPortfolios();
    }
  }

  public void displayHeader() {

    JLabel nameofProgram = new JLabel("Welcome to Our Stock Market");
    JLabel instructions = new JLabel("Here are the Following Portfolios in Our System");


    nameofProgram.setFont(new Font("Times New Roman", Font.BOLD, 40));
    nameofProgram.setForeground(Color.BLUE);

    instructions.setFont(new Font("Times New Roman", Font.BOLD, 20));

    instructions.setForeground(Color.BLUE);

    mainPanel.setLayout(new BorderLayout());
    mainPanel.setPreferredSize(new Dimension(800, 400));

    JPanel headerPanel = new JPanel();
    headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
    headerPanel.add(nameofProgram);
    headerPanel.add(instructions);
    nameofProgram.setAlignmentX(Component.CENTER_ALIGNMENT);
    instructions.setAlignmentX(Component.CENTER_ALIGNMENT);

    mainPanel.add(headerPanel);
  }

  public void displayButtonOptions() {

    // Set up buttons
    Font buttonFont = new Font("Times New Roman", Font.BOLD, 12);
    Dimension buttonSize = new Dimension(160, 100);

    this.createPortfolio.setFont(buttonFont);
    this.createPortfolio.setPreferredSize(buttonSize);

    this.buyStock.setFont(buttonFont);
    this.buyStock.setPreferredSize(buttonSize);

    this.sellStock.setFont(buttonFont);
    this.sellStock.setPreferredSize(buttonSize);

    this.valueOfPortfolio.setFont(buttonFont);
    this.valueOfPortfolio.setPreferredSize(buttonSize);

    this.composition.setFont(buttonFont);
    this.composition.setPreferredSize(buttonSize);

//    JPanel newButtonPanel = new JPanel();
//    getPortfolioButtions();
//
//    for(int i = 0; i < portfolioButtons.size(); i++){
//      portfolioButtons.get(i).setFont(buttonFont);
//      portfolioButtons.get(i).setPreferredSize(buttonSize);
//      newButtonPanel.add(portfolioButtons.get(i));
//    }

    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new GridLayout(1, 5, 10, 10));
    buttonPanel.add(this.createPortfolio);


    //mainPanel.add(newButtonPanel, BorderLayout.CENTER);
    mainPanel.add(buttonPanel, BorderLayout.SOUTH);

    add(mainPanel, BorderLayout.CENTER);
  }

  public void displayPort() {
    JPanel newButtonPanel = new JPanel();

    getPortfolioButtions();
    Font buttonFont = new Font("Times New Roman", Font.BOLD, 12);
    Dimension buttonSize = new Dimension(160, 100);


    for(int i = 0; i < portfolioButtons.size(); i++){
      portfolioButtons.get(i).setFont(buttonFont);
      portfolioButtons.get(i).setPreferredSize(buttonSize);
      newButtonPanel.add(portfolioButtons.get(i));
      newButtonPanel.setLayout(new GridLayout(i, i, 5, 5));
    }


    mainPanel.add(newButtonPanel, BorderLayout.CENTER);
  }

//  @Override
//  public void keyTyped(KeyEvent e) {
//    if ( e.getKeyChar() == 's'){
//      fireSetDataEvent();
//    }
//    else if ( e.getKeyChar() == 'g'){
//      fireGetDataEvent();
//    }
//  }

//  @Override
//  public void keyPressed(KeyEvent e) {
//
//  }
//
//  @Override
//  public void keyReleased(KeyEvent e) {
//
//  }
//
//  @Override
//  public void mouseClicked(MouseEvent e) {
//
//  }
//
//  @Override
//  public void mousePressed(MouseEvent e) {
//
//  }
//
//  @Override
//  public void mouseReleased(MouseEvent e) {
//
//  }
//
//  @Override
//  public void mouseEntered(MouseEvent e) {
//
//  }
//
//  @Override
//  public void mouseExited(MouseEvent e) {
//
//  }



  @Override
  public void addViewListener(IViewListener listener){
    this.myListeners.add(Objects.requireNonNull(listener));
  }



}
