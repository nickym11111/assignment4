package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

import javax.swing.text.View;

import model.ISmartPortfolio;
import model.ISmartStockMarket;
import model.IStockMarket;
import view.IView;
import view.IViewGUI;
import view.IViewListener;

/**
 * Created by vidojemihajlovikj on 6/10/24.
 */
public class StockControllerGUI implements IController, IViewListener {
  private final IStockMarket stockMarket;
  private final IViewGUI view;

  public StockControllerGUI(IStockMarket stockMarket, IViewGUI view) {
    this.stockMarket = Objects.requireNonNull(stockMarket);
    this.view = Objects.requireNonNull(view);
    this.view.addViewListener(this);
  }

  @Override
  public void goController() {
    view.setVisible(true);


    view.displayHeader();
    view.displayButtonOptions();
    view.displayPort();
  }
  //public void handleGetDataForStockAndDate(String ticker, String date){
  /*
      IStock stock = this.model.getStock(ticker);
      double price = stock.getPrice(date);
      view.displayStock(ticker, price);
   */

  @Override
  public void handleDisplayPortfolios() {
    Map<String, ISmartPortfolio> portfolios = this.stockMarket.getPortfolios();
    StringBuilder sb = new StringBuilder();
    for( Map.Entry<String, ISmartPortfolio> entry : portfolios.entrySet() ){
      sb.append(entry.getKey());
      sb.append("\n");
    }
    this.view.displayPortfolios(sb.toString());
    //this.view.requestFocus();
  }

  public void getPortfolioButtons() {
    Map<String, ISmartPortfolio> portfolios = this.stockMarket.getPortfolios();
    ArrayList<String> names = new ArrayList<>(portfolios.keySet());
    this.view.setPortfolioButtons(names);
    this.view.requestFocus();
  }
}
