package model;

public interface ISmartStockMarket extends IStockMarket {
  void setData(String data);
  String getData();
}
