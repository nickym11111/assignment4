package model;

import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SmartPortfolio extends Portfolio implements ISmartPortfolio {
  protected Map<String, ArrayList<ISmartStockShares>> bought;
  protected Map<String, ArrayList<ISmartStockShares>> sold;
  protected Map<String, ISmartStockShares> current;

  protected LocalDate dateCreated;

  public SmartPortfolio(String name) {
    super(name);
    bought = new HashMap<>();
    sold = new HashMap<>();
    current = new HashMap<>();
  }

  @Override
  public void addStockShare(String ticker, IStock stock, int shares)
          throws FileNotFoundException {
    ISmartStockShares stockShares = new SmartStockShares(shares, stock);
    stockShares.setBought(true);
    stockShares.setDate(LocalDate.now());
    if(dateCreated != null) {
      dateCreated = LocalDate.now();
    }
    if(bought.containsKey(ticker)) {
      bought.get(ticker).add(stockShares);
    }
    else {
      ArrayList<ISmartStockShares> stockSharesArrayList = new ArrayList<>();
      stockSharesArrayList.add(stockShares);
      bought.put(ticker, stockSharesArrayList);
      current = portfolioStateAtDate(LocalDate.now());
    }
  }


  /**
   * Removes shares of a stock to the portfolio.
   *
   * @param ticker the ticker symbol of the stock
   * @param stock  the stock to remove shares of
   * @param shares the number of shares to remove
   * @throws FileNotFoundException if the file containing the stock data is not found
   */
  public void removeStockShare(String ticker, IStock stock, int shares)
          throws FileNotFoundException {
    if(sold.containsKey(ticker)) {
      sold.get(ticker).add(new SmartStockShares(shares, stock));
    }
    else {
      ArrayList<ISmartStockShares> stockShare = new ArrayList<>();
      stockShare.add(new SmartStockShares(shares, stock));
      sold.put(ticker, stockShare);
      current = portfolioStateAtDate(LocalDate.now());
    }
  }


  public HashMap<String, ISmartStockShares> portfolioStateAtDate(LocalDate date)
          throws FileNotFoundException {
    HashMap<String, ISmartStockShares> portfolioState = new HashMap<>();
    for(Map.Entry<String, ArrayList<ISmartStockShares>> entry : bought.entrySet()) {
      ISmartStockShares s = stockSharesAtDate(date, entry.getValue());
      if(s.getShares() != 0) {
        portfolioState.put(entry.getKey(), s);
      }
    }
    return portfolioState;
  }

  private ISmartStockShares stockSharesAtDate(LocalDate date,
                                        ArrayList<ISmartStockShares> stockSharesList)
          throws FileNotFoundException {
    int sumShares = 0;
    IStock stock = stockSharesList.get(0).getStock();

    for(int i = 0; i < stockSharesList.size(); i++) {
      if(stockSharesList.get(i).getDate().equals(date)
              || stockSharesList.get(i).getDate().isAfter(date)) {

        sumShares += stockSharesList.get(i).getShares();
      }
    }
    ISmartStockShares updatedStockForDate = new SmartStockShares(sumShares, stock);
    updatedStockForDate.setDate(stockSharesList.getLast().getDate());
    return updatedStockForDate;
  }

  public Map<String, ArrayList<ISmartStockShares>> getBoughtStockSharesMap() {
    return bought;
  }

  public Map<String, ArrayList<ISmartStockShares>> getSoldStockSharesMap() {
    return sold;
  }

  public Map<String, ISmartStockShares> getCurrentStockSharesMap() {
    return current;
  }

  public void setCurrentStockSharesMap(Map<String,  ISmartStockShares> currentStockSharesMap) {
    this.current = currentStockSharesMap;
  }

  public void setBoughtStockSharesMap(Map<String, ArrayList<ISmartStockShares>> bought) {
    this.bought = bought;
  }

  public void setSoldStockSharesMap(Map<String, ArrayList<ISmartStockShares>> sold) {
    this.sold = sold;
  }


}
