package model;

import java.io.FileNotFoundException;
import java.time.LocalDate;

public class SmartStockShares extends StockShares implements ISmartStockShares {
  private LocalDate date;
  private boolean bought;

  public SmartStockShares(double shares, IStock stock) throws FileNotFoundException {
    super(shares, stock);
  }


  public LocalDate getDate() {
    return date;
  }

  public void setDate(LocalDate date) {
    this.date = date;
  }

  public boolean isBought() {
    return bought;
  }

  public void setBought(boolean bought) {
    this.bought = bought;
  }

}
