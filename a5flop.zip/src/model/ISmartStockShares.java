package model;

import java.time.LocalDate;

public interface ISmartStockShares extends IStockShares{

  LocalDate getDate();


   void setDate(LocalDate date);
   boolean isBought();

   void setBought(boolean bought) ;
}
