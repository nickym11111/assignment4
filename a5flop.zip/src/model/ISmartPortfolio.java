package model;

import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public interface ISmartPortfolio extends IPortfolio{


  /**
   * Removes a specified number of shares of a stock to the portfolio.
   *
   * @param ticker the ticker symbol of the stock
   * @param stock  the stock to be added
   * @param shares the number of shares to be removed
   * @throws FileNotFoundException if the stock data file is not found
   */
  void removeStockShare(String ticker, IStock stock, int shares) throws FileNotFoundException;;

  /**
   * Retrieves the current state of the portfolio with information such as the stocks in that
   * portfolio and the amount of shares owned of that specific stock.
   * @param date the date that the user would like to obtain the information of the portfolio.
   * @return The stock and the shares owned for that stock.
   */
  HashMap<String, ISmartStockShares> portfolioStateAtDate(LocalDate date) throws FileNotFoundException;

  Map<String, ArrayList<ISmartStockShares>> getBoughtStockSharesMap();
  Map<String,   ArrayList<ISmartStockShares>> getSoldStockSharesMap();

  void setCurrentStockSharesMap(Map<String, ISmartStockShares> currentStockSharesMap);

  void setBoughtStockSharesMap(Map<String, ArrayList<ISmartStockShares>> bought);

  void setSoldStockSharesMap(Map<String, ArrayList<ISmartStockShares>> sold);


  Map<String, ISmartStockShares> getCurrentStockSharesMap();
}
