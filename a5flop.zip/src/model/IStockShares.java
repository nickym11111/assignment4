package model;

public interface IStockShares {
  double getShares(); // changed to double
  IStock getStock();
  boolean equals(Object obj);
  String toString();
  int hashCode();
}
