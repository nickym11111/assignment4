package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.swing.*;

public class ViewGUIImpl extends JFrame implements IViewGUI, ActionListener {

  private final JButton createPortfolio = new JButton("Create Portfolio");
  private final JButton  buyStock = new JButton("Buy Stock");
  private final JButton  sellStock = new JButton("Sell Stock");
  private final JButton valueOfPortfolio = new JButton("Value of Portfolio");
  private final JButton composition = new JButton("Composition of Portfolio");
  private final JPanel mainPanel = new JPanel();


  //  private final JLabel  enterTextLabel;
//  private final JTextArea enterTextArea;
  private final List<IViewListener> myListeners;

  public ViewGUIImpl(){
    super("Stock Portfolio Manager");
    setSize(new Dimension(800, 400));
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    this.myListeners = new ArrayList<>();
    setLayout(new BorderLayout());


    displayHeader();
    displayButtonOptions();

//    setFocusable(true);
//    requestFocus();

    // pack();
    setVisible(true);

  }


  @Override
  public void writeMessage(String message) {

  }

  @Override
  public void actionPerformed(ActionEvent e) {
    switch ( e.getActionCommand() ){
      case "getData":
        // fireGetDataEvent();
        break;
      case "sendData":
        // fireSetDataEvent();
        break;
      default:
        throw new IllegalStateException("Unknown action command");
    }
    //Which button got cliked!
  }


  private void fireGetDataEvent(){
    for ( IViewListener myListener : myListeners ){
      myListener.handleGetData();
    }
  }

  private void fireSetDataEvent(){
    for ( IViewListener myListener : myListeners ){
      myListener.handleSetData();
    }
  }


  private void displayHeader() {

    JLabel nameofProgram = new JLabel("Welcome to Our Stock Market");
    JLabel instructions = new JLabel("Here are the Following Portfolios in Our System");

    nameofProgram.setFont(new Font("Times New Roman", Font.BOLD, 40));
    nameofProgram.setForeground(Color.BLUE);

    instructions.setFont(new Font("Times New Roman", Font.BOLD, 20));

    instructions.setForeground(Color.BLUE);

    mainPanel.setLayout(new BorderLayout());
    mainPanel.setPreferredSize(new Dimension(800, 400));

    JPanel headerPanel = new JPanel();
    headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
    headerPanel.add(nameofProgram);
    headerPanel.add(instructions);
    nameofProgram.setAlignmentX(Component.CENTER_ALIGNMENT);
    instructions.setAlignmentX(Component.CENTER_ALIGNMENT);

    mainPanel.add(headerPanel);

  }

  private void displayButtonOptions() {

    // Set up buttons
    Font buttonFont = new Font("Times New Roman", Font.BOLD, 12);
    Dimension buttonSize = new Dimension(160, 100);

    this.createPortfolio.setFont(buttonFont);
    this.createPortfolio.setPreferredSize(buttonSize);

    this.buyStock.setFont(buttonFont);
    this.buyStock.setPreferredSize(buttonSize);

    this.sellStock.setFont(buttonFont);
    this.sellStock.setPreferredSize(buttonSize);

    this.valueOfPortfolio.setFont(buttonFont);
    this.valueOfPortfolio.setPreferredSize(buttonSize);

    this.composition.setFont(buttonFont);
    this.composition.setPreferredSize(buttonSize);

    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new GridLayout(1, 5, 10, 10));
    buttonPanel.add(this.createPortfolio);
//    buttonPanel.add(this.buyStock);
//    buttonPanel.add(this.sellStock);
//    buttonPanel.add(this.valueOfPortfolio);
//    buttonPanel.add(this.composition);

    this.createPortfolio.addActionListener(this);
    this.buyStock.addActionListener(this);
    this.sellStock.addActionListener(this);
    this.valueOfPortfolio.addActionListener(this);
    this.composition.addActionListener(this);

    mainPanel.add(buttonPanel, BorderLayout.SOUTH);
    add(mainPanel, BorderLayout.CENTER);
  }

//  @Override
//  public void keyTyped(KeyEvent e) {
//    if ( e.getKeyChar() == 's'){
//      fireSetDataEvent();
//    }
//    else if ( e.getKeyChar() == 'g'){
//      fireGetDataEvent();
//    }
//  }

//  @Override
//  public void keyPressed(KeyEvent e) {
//
//  }
//
//  @Override
//  public void keyReleased(KeyEvent e) {
//
//  }
//
//  @Override
//  public void mouseClicked(MouseEvent e) {
//
//  }
//
//  @Override
//  public void mousePressed(MouseEvent e) {
//
//  }
//
//  @Override
//  public void mouseReleased(MouseEvent e) {
//
//  }
//
//  @Override
//  public void mouseEntered(MouseEvent e) {
//
//  }
//
//  @Override
//  public void mouseExited(MouseEvent e) {
//
//  }

  @Override
  public String getData(){
    return String.valueOf(this.buyStock.getText());
  }


  @Override
  public void setData(String data){
    return;
  }



  @Override
  public void addViewListener(IViewListener listener){
    this.myListeners.add(Objects.requireNonNull(listener));
  }

}
