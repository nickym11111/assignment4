package controller;

import java.io.IOException;

/**.
 * This interface defines the contract for starting the stock program.
 */
public interface IController {

    /**
     * Starts the controller, initiating the application's main logic.
     * @throws IOException if an I/O error occurs during controller execution
     */
    void go() throws IOException;
}
