**Prerequisites:**

1.
   - Ensure you have Java installed on your system. You can verify this by running `java -version` in your command line.
   - If Java is not installed, download and install it from the official website: https://www.oracle.com/java/technologies/javase-jdk11-downloads.html


** Creating and Managing Stocks **

- **Important Notes:**
  - Ensure that the dates entered are within the supported ranges for each stock.
  - The program will notify you if the entered date is not available or invalid. However,
    calculating the moving average, crossover days,

List of Supported Stocks:

  - AAPL (Apple Inc.)
  - MFST (Microsoft Corporation)
  - GOOG (Alphabet Inc.)
  - META (Facebook, Inc.)
  - AMZN (Amazon.com)

Available Dates for Stock Date:

   - AAPL: 1999-11-01 to 2024-6-7
   - MFST: 1999-11-01 to 2024-6-7
   - GOOGL: 1999-11-01 to 2024-6-7
   - META: 1999-11-01 to 2024-6-7
   - AMZN: 1999-11-01 to 2024-6-7


 ** Creating and Managing Portfolios **

Create Portfolio1 with 3 stocks
Once the program is running, follow these steps:

     1. Select the option to create a new portfolio.
 Type: Enter 'portfolio' to create a new portfolio

     2. Select the option "p"

     3. Enter the name for your new portfolio when prompted.
 Type: name of choice

     4. Enter the amount of stock you will being adding.
 Type: amount greater than 0

    5. How would you input the stock data?
 Type : ‘a’ for API
 Type “ ‘f’ for saved files

   6. If types ‘f" Enter CSV file
 Type : STOCKTICKERSYMBOL.csv

   7. If types ‘f" Enter CSV file
   Type : STOCKTICKERSYMBOL.csv





Create Portfolio2 with 2 stocks
Once the program is running, follow these steps:

     1. Select the option to create a new portfolio.
 Command: Enter 'c' to create a new portfolio

     2. Enter the name for your new portfolio when prompted.
 Command: Enter portfolio name: MyPortfolio1

     3. Add three different stocks to this portfolio by entering the ticker symbols and the number of shares for each.
Command:  Enter 's' to add a stock to the portfolio
Command:  Enter stock ticker symbol: AAPL
Command:  Enter number of shares: 10

Command:  Enter 's' to add a stock to the portfolio
Command:  Enter stock ticker symbol: MFST
Command:  Enter number of shares: 10









