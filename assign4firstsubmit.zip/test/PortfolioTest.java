import model.IPortfolio;
import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.util.HashMap;

import model.Portfolio;
import model.StockShares;

import static org.junit.Assert.*;

/**
 * A test class that guarantees that different functionality of portfolio
 * property works and can be obtained.
 */
public class PortfolioTest extends ModelDataTest {
    private IPortfolio portfolio;


    @Before
    public void setUp() {
        this.portfolio = new Portfolio("Technology");
    }


    @Test
    public void testAddStockShare() throws FileNotFoundException {
        StockShares expected = new StockShares(5, this.amazonStock);
        this.portfolio.addStockShare("AMZN", this.amazonStock, 5);


        assertEquals(expected, this.portfolio.getStocksShareMap().get("AMZN"));
    }

    @Test
    public void testGetStockShare() throws FileNotFoundException {
        StockShares expected = new StockShares(5, this.amazonStock);
        this.portfolio.addStockShare("AMZN", this.amazonStock, 5);
        HashMap<String, StockShares> expectedMap = new HashMap<>();
        expectedMap.put("AMZN", expected);


        assertEquals(expectedMap, this.portfolio.getStocksShareMap());
    }


    @Test
    public void testGetName() {

        assertEquals("Technology", portfolio.getName());
    }


}